# boostApp Repo 


This Repository contains three module 

### A simple Springboot rest Application pipeline
readme Doc Link - https://github.com/OpsMx/boostApp/blob/master/src/README.md

### Jenkins job
readme Doc Link - https://github.com/OpsMx/boostApp/blob/master/jenkins/README.md

### spinnaker pipeline
readme Doc Link - https://github.com/OpsMx/boostApp/blob/master/spinnaker/README.md

