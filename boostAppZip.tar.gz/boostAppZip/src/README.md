# Source code of spring-boot app 

This folder contains source code of a simple spingboot rest application

To build by maven 
./mvn clean install -e 

After building 
in the target folder, boostApp.jar will create after finishing a build process

Run jar by command 
java  -jar restapp.jar

access by this URL  http://localhost:8090/greeting


